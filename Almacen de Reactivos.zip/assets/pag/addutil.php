<?php

include('conexion.php');
include('plantilla2.php'); 

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Añadir Utencilio de Laboratorio</h1>
      </div>
        
      
<form class="needs-validation" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>">
                          <div class="row g-3">
                          <div class="col-sm-12">
                                <label for="Almacen" class="form-label">Almacén</label>
                                <select class="form-select" name='almacen' required>
                                    <?php 
                                    
                                    $solicitud = "SELECT * FROM almacenes";
                                    $resultado = mysqli_query($conexion, $solicitud);

                                    while($fila = mysqli_fetch_array($resultado)){
                                        echo "<option>". $fila['almacen']."</option>";
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                            <div class="col-sm-12">
                                <label for="Articulo" class="form-label">Articulo</label>
                              <input type="text" class="form-control" name="articulo" placeholder="Nombre del Artículo" value="" required>
                            </div>
                            <div class="col-sm-4">
                             <label for="Estante" class="form-label">Estante</label>
                              <input type="number" class="form-control" name="estante" placeholder="Estante" value="" required>
                            </div>
                            <div class="col-sm-4">
                             <label for="Nivel" class="form-label">Nivel</label>
                              <input type="number" class="form-control" name="nivel" placeholder="Nivel" value="" required>
                            </div>
                            <div class="col-sm-4">
                            <label for="Cantidad" class="form-label">Cantidad</label>
                              <input type="number" class="form-control" name="cantidad" placeholder="Cantidad de Unidades" value="" required>
                            </div>
                            <div class="text-end">
                          <a href="gestutiles.php" class="btn btn-secondary">Volver</a>
                            <input type="submit" class="btn btn-primary" name="agregar" value="Añadir">
                            </div>
                          </div>
                          
                      </form>
                      <?php 
                      if (isset($_POST['agregar'])) {

                        $almacen = $_POST['almacen'];
                        $articulo = $_POST['articulo'];
                        $estante = $_POST['estante'];
                        $nivel = $_POST['nivel'];
                        $cantidad = $_POST['cantidad'];
                      

                        
                        $solicitud1 = "INSERT INTO entradasu (almacen, articulo, cantidad) VALUES('$almacen', '$articulo', '$cantidad')";
                        $resultado1 = mysqli_query($conexion, $solicitud1);

                            $solicitud1 = "SELECT * FROM utiles WHERE almacen='$almacen' AND articulo='$articulo' AND estante='$estante' AND nivel='$nivel'" ;
                                          $resultado1 = mysqli_query( $conexion, $solicitud1);
                                          
                                          $filas = mysqli_num_rows($resultado1);
                                          
                                              if($filas){
                                                while($fila = mysqli_fetch_array($resultado1)){
                                                  $id = $fila['ID'];
                                                  $cantidad1 = $fila['cantidad'] + $cantidad;
                                                }
                                                $solicitud2 = "UPDATE utiles SET cantidad='$cantidad1' WHERE ID='$id'";
                                                $resultado2 = mysqli_query( $conexion, $solicitud2);

                                              
                                              }else{
                                                $solicitud = "INSERT INTO utiles (almacen, articulo, estante, nivel, cantidad) VALUES('$almacen', '$articulo', '$estante', '$nivel', '$cantidad')";
                                                $resultado = mysqli_query($conexion, $solicitud);
                        
                                                  
                                              }


                      }
                      ?>
      </div>
    </main>
  </div>
</div>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="assets/js/dashboard.js"></script>
  </body>
</html>