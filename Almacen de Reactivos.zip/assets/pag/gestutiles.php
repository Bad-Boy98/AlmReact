<?php

include('conexion.php');
include('plantilla2.php');

$solicitud = "SELECT * FROM utiles";
$resultado = mysqli_query($conexion, $solicitud);

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Almacén de Útiles de Laboratorio</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="addutil.php" class="btn btn-sm btn-outline-secondary">Añadir</a>
          </div>
        </div>
      </div>
      <div class="table-responsive">
        <table id="tableID" class="table table-hover">
          <thead>
          <tr>
              <th scope="col">Almacén</th>
              <th scope="col">Artículo</th>
              <th scope="col">Estante</th>
              <th scope="col">Nivel</th>
              <th scope="col">Cantidad</th>
              <th scope="col">Acciones</th>
          </thead>
          <tbody>
          <?php 
            while($fila = mysqli_fetch_array($resultado)){
                echo "<tr>";  
                echo "<td>". $fila['almacen']."</td>"; 
                echo "<td>". $fila['articulo']."</td>";
                echo "<td>". $fila['estante']."</td>";
                echo "<td>". $fila['nivel']."</td>";
                echo "<td>". $fila['cantidad']."</td>"; 
                echo "<td class='text-center'><a class='btn btn-primary' style='--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;' href='formactutil.php?id=". $fila['ID']."'>Actualizar</a></td>";
                echo "</tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      </div>
    </main>
  </div>
</div>

    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="assets/js/dashboard.js"></script>
  
      <script>
  
  // Initialize the DataTable
  $(document).ready(function () {
    $('#tableID').DataTable({

      lengthMenu: [ 10, 15, 20, 25, 30 ],
        
      language: {
            url: '../es-ES.json'
        }
      // Set the starting row
      // of the DataTable
    });
  }); 
</script>
  
    </body>
</html>

