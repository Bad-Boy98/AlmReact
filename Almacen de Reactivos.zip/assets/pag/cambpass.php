<?php

include('conexion.php');

$id = $_POST['id'];

$solicitud = "SELECT * FROM users WHERE ID=$id";
$resultado = mysqli_query($conexion, $solicitud);

  while ($fila = mysqli_fetch_array($resultado)) {
      $pass1 = $fila['pass'];
  }


$apass = $_POST['apass'];
$pass = $_POST['pass'];
$passconf = $_POST['passconf'];
                  
                      if($apass == $pass1 && $pass==$passconf) {

                        $solicitud1 = "UPDATE users SET pass='$pass' WHERE ID='$id'";
                        $resultado1 = mysqli_query( $conexion, $solicitud1);
                        header("location: gestuser.php");

                      }else{

                        header("location: gestuser.php");
                      }




  ?>