<?php

date_default_timezone_get();

$fechaActual = date("d/m/Y");


echo $fechaActual;

?>