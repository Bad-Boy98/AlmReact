<?php

include('conexion.php');
include('plantilla2.php'); 



?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Actualizar Estado del Reactivo</h1>
      </div>
        
      
<form class="needs-validation" method="POST" action="actreact.php">
                          <div class="row g-3">
                          <div class="col-sm-12">
                                <label for="Almacen" class="form-label">Almacén</label>
                                <select class="form-select" name='almacen' required>
                                    <?php 
                                    
                                    $solicitud = "SELECT * FROM almacenes";
                                    $resultado = mysqli_query($conexion, $solicitud);

                                    while($fila = mysqli_fetch_array($resultado)){
                                        echo "<option>". $fila['almacen']."</option>";
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                            <?php
                            $id = $_GET["id"];
                            $solicitud = "SELECT * FROM reactivos WHERE ID=$id";
                                    $resultado = mysqli_query($conexion, $solicitud);

                                    while($fila = mysqli_fetch_array($resultado)){
                              $noFrascos1 = $fila['noFrascos'];
                            echo "<div class='col-sm-6'>
                                <label for='Reactivo' class='form-label'>Reactivo</label>
                              <input type='text' class='form-control' name='reactivo' value=". $fila['reactivo']." required>
                            </div>
                            <div class='col-sm-6'>
                                <label for='Fórmula' class='form-label'>Fórmula</label>
                              <input type='text' class='form-control' name='formula' value=". $fila['formula']." required>
                            </div>
                            <div class='col-sm-4'>
                             <label for='Estante' class='form-label'>Estante</label>
                              <input type='text' class='form-control' name='estante' value=". $fila['estante']." required>
                            </div>
                            <div class='col-sm-4'>
                             <label for='Nivel' class='form-label'>Nivel</label>
                              <input type='text' class='form-control' name='nivel' value=". $fila['nivel']." required>
                            </div>
                            <div class='col-sm-4'>
                            <label for='Marca' class='form-label'>Marca</label>
                              <input type='text' class='form-control' name='marca' value=". $fila['marca']." required>
                            </div>
                            <div class='col-sm-6'>
                             <label for='#Frascos' class='form-label'>#Frascos</label>
                              <input type='text' class='form-control' name='noFrascos' value=". $fila['noFrascos']." required>
                            </div>
                            <div class='col-sm-6'>
                             <label for='Cantidad en Frasco' class='form-label'>Cantidad en Frasco</label>
                              <input type='text' class='form-control' name='cantFrasco' value=". $fila['cantFrasco']." required>
                            </div>
                            <input type='hidden' name='noFrascos1' value=".$noFrascos1.">
                            <input type='hidden' name='id' value=".$id.">
                        
                            <div class='text-end'>
                          <a href='gestreact.php' class='btn btn-secondary'>Cancelar</a>
                            <input type='submit' class='btn btn-primary' name='actualizar' value='Actualizar'>
                            </div>
                          </div>";
                        }
                        ?>
                      </form>
      </div>
    </main>
  </div>
</div>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="assets/js/dashboard.js"></script>
  </body>
</html>