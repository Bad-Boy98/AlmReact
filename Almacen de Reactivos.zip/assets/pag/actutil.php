<?php
include('conexion.php');

                        $id = $_POST['id'];
                        $almacen = $_POST['almacen'];
                        $articulo = $_POST['articulo'];
                        $estante = $_POST['estante'];
                        $nivel = $_POST['nivel'];
                        $cantidad = $_POST['cantidad'];
                        $cantidad1 = $_POST['cantidad1'];
                        
                        $solicitud1 = "UPDATE utiles SET almacen='$almacen', articulo='$articulo', estante='$estante', nivel='$nivel', cantidad='$cantidad' WHERE ID='$id'";
                        $resultado1 = mysqli_query( $conexion, $solicitud1);

                        if($cantidad > $cantidad1 ){

                          $cantidad2 = $cantidad - $cantidad1 ;

                          $solicitud1 = "INSERT INTO entradasu (almacen, articulo, cantidad) VALUES('$almacen', '$articulo', '$cantidad2')";
                          $resultado1 = mysqli_query($conexion, $solicitud1);

                        }else{

                          $cantidad3 = $cantidad1 - $cantidad ;

                          $solicitud1 = "INSERT INTO salidasu (almacen, articulo, cantidad) VALUES('$almacen', '$articulo', '$cantidad3')";
                          $resultado1 = mysqli_query($conexion, $solicitud1);
  
                        }

                        header("location: gestreact.php");
?>