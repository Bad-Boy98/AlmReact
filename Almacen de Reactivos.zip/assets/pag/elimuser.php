<?php 
include('conexion.php');
$id = $_GET['id'];
              $solicitud2 = "DELETE FROM users WHERE ID=$id";
              $resultado2 = mysqli_query($conexion, $solicitud2);
            
              header("location: gestuser.php");
?>
