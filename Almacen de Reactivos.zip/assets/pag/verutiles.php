<?php
include('conexion.php');
include('plantilla1.php');  

$solicitud = "SELECT * FROM utiles";
$resultado = mysqli_query($conexion, $solicitud);

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Almacén de Útiles de  Laboratorio</h1>
        </div>
      </div>
      <div class="table-responsive">
      <table id="tableID" class="table table-hover">
          <thead>
          <tr>
              <th scope="col">Almacén</th>
              <th scope="col">Artículo</th>
              <th scope="col">Estante</th>
              <th scope="col">Nivel</th>
              <th scope="col">Cantidad</th>
          </thead>
          <tbody>
          <?php 
            while($fila = mysqli_fetch_array($resultado)){
                echo "<tr>";  
                echo "<td>". $fila['almacen']."</td>"; 
                echo "<td>". $fila['articulo']."</td>";
                echo "<td>". $fila['estante']."</td>";
                echo "<td>". $fila['nivel']."</td>";
                echo "<td>". $fila['cantidad']."</td>"; 
                echo "</tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      </div>
    </main>
    <script>
  
  // Initialize the DataTable
  $(document).ready(function () {
    $('#tableID').DataTable({

      lengthMenu: [ 10, 15, 20, 25, 30 ],
        

      language: {
            url: '../es-ES.json'
        }
      // Set the starting row
      // of the DataTable
    });
  }); 
</script>