<?php

include('conexion.php');
include('plantilla2.php'); 

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Añadir Reactivo</h1>
      </div>
        
      
<form class="needs-validation" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>">
                          <div class="row g-3">
                          <div class="col-sm-12">
                                <label for="Almacen" class="form-label">Almacén</label>
                                <select class="form-select" name='almacen' required>
                                    <?php 
                                    
                                    $solicitud = "SELECT * FROM almacenes";
                                    $resultado = mysqli_query($conexion, $solicitud);

                                    while($fila = mysqli_fetch_array($resultado)){
                                        echo "<option>". $fila['almacen']."</option>";
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label for="Reactivo" class="form-label">Reactivo</label>
                              <input type="text" class="form-control" name="reactivo" placeholder="Nombre del Reactivo" value="" required>
                            </div>
                            <div class="col-sm-6">
                                <label for=Fórmula" class="form-label">Fórmula</label>
                              <input type="text" class="form-control" name="formula" placeholder="Fórmula" value="" required>
                            </div>
                            <div class="col-sm-4">
                             <label for="Estante" class="form-label">Estante</label>
                              <input type="number" class="form-control" name="estante" placeholder="Estante" value="" required>
                            </div>
                            <div class="col-sm-4">
                             <label for="Nivel" class="form-label">Nivel</label>
                              <input type="number" class="form-control" name="nivel" placeholder="Nivel" value="" required>
                            </div>
                            <div class="col-sm-4">
                            <label for=Marca" class="form-label">Marca</label>
                              <input type="text" class="form-control" name="marca" placeholder="Marca del Reactivo" value="" required>
                            </div>
                            <div class="col-sm-6">
                             <label for="#Frascos" class="form-label">#Frascos</label>
                              <input type="number" class="form-control" name="noFrascos" placeholder="Cantidad de Frascos" value="" required>
                            </div>
                            <div class="col-sm-6">
                             <label for="Cantidad en Frasco" class="form-label">Cantidad en Frasco</label>
                              <input type="number" class="form-control" name="cantFrasco" placeholder="Cantidad en cada Frasco" value="" required>
                            </div>
                            <div class="text-end">
                          <a href="gestreact.php" class="btn btn-secondary">Volver</a>
                            <input type="submit" class="btn btn-primary" name="agregar" value="Añadir">
                            </div>
                          </div>
                          
                      </form>
                      <?php 
                      if (isset($_POST['agregar'])) {

                        $almacen = $_POST['almacen'];
                        $reactivo = $_POST['reactivo'];
                        $formula = $_POST['formula'];
                        $estante = $_POST['estante'];
                        $nivel = $_POST['nivel'];
                        $marca = $_POST['marca'];
                        $noFrascos = $_POST['noFrascos'];
                        $cantFrasco = $_POST['cantFrasco'];
                        $cantTotal = $noFrascos * $cantFrasco;
                        $fecha = date("d/m/Y");


                        $solicitud = "INSERT INTO entradasr (almacen, fecha, reactivo, marca, noFrascos, cantFrasco) VALUES('$almacen', '$fecha', '$reactivo', '$marca', '$noFrascos', '$cantFrasco')";
                        $resultado = mysqli_query($conexion, $solicitud);

                            $solicitud1 = "SELECT * FROM reactivos WHERE almacen='$almacen' AND reactivo='$reactivo' AND estante='$estante' AND nivel='$nivel' AND marca='$marca'  AND cantFrasco='$cantFrasco'" ;
                                          $resultado1 = mysqli_query( $conexion, $solicitud1);
                                          
                                          $filas = mysqli_num_rows($resultado1);
                                          
                                              if($filas){
                                                while($fila = mysqli_fetch_array($resultado1)){
                                                  $id = $fila['ID'];
                                                  $noFrascos1 = $fila['noFrascos'] + $noFrascos;
                                                  $cantTotal1 = $fila['cantFrasco'] * $noFrascos1;
                                                }
                                                $solicitud2 = "UPDATE reactivos SET noFrascos='$noFrascos1', cantTotal='$cantTotal1' WHERE ID='$id'";
                                                $resultado2 = mysqli_query( $conexion, $solicitud2);

                                              
                                              }else{
                                                $solicitud3 = "INSERT INTO reactivos (almacen, reactivo, formula, estante, nivel, marca, noFrascos, cantFrasco, cantTotal) VALUES('$almacen', '$reactivo', '$formula', '$estante', '$nivel', '$marca', '$noFrascos', '$cantFrasco', '$cantTotal')";
                                                $resultado3 = mysqli_query($conexion, $solicitud3);
                        
                                                  
                                              }
                      
                      }
                      ?>
      </div>
    </main>
  </div>
</div>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="assets/js/dashboard.js"></script>
  </body>
</html>