<?php
include('conexion.php');

                        $id = $_POST['id'];
                        $almacen = $_POST['almacen'];
                        $reactivo = $_POST['reactivo'];
                        $formula = $_POST['formula'];
                        $estante = $_POST['estante'];
                        $nivel = $_POST['nivel'];
                        $marca = $_POST['marca'];
                        $noFrascos = $_POST['noFrascos'];
                        $cantFrasco = $_POST['cantFrasco'];
                        $cantTotal = $noFrascos * $cantFrasco;
                        $noFrascos1 = $_POST['noFrascos1'];
                        $fecha = date("d/m/Y");
                        
                        $solicitud1 = "UPDATE reactivos SET almacen='$almacen', reactivo='$reactivo', formula='$formula', estante='$estante', nivel='$nivel', marca='$marca', noFrascos='$noFrascos', cantFrasco='$cantFrasco', cantTotal='$cantTotal' WHERE ID='$id'";
                        $resultado1 = mysqli_query( $conexion, $solicitud1);

                        if($noFrascos > $noFrascos1 ){

                          $noFrascos2 = $noFrascos - $noFrascos1 ;

                          $solicitud1 = "INSERT INTO entradasr (almacen, fecha, reactivo, marca, noFrascos, cantFrasco) VALUES('$almacen', '$fecha', '$reactivo', '$marca', '$noFrascos2', '$cantFrasco')";
                          $resultado1 = mysqli_query($conexion, $solicitud1);

                        }else{

                          $noFrascos3 = $noFrascos1 - $noFrascos ;

                          $solicitud1 = "INSERT INTO salidasr (almacen, fecha, reactivo, marca, noFrascos, cantFrasco) VALUES('$almacen', '$fecha', '$reactivo', '$marca', '$noFrascos3', '$cantFrasco')";
                          $resultado1 = mysqli_query($conexion, $solicitud1);
  
                            
                        }

                        header("location: gestreact.php");
?>