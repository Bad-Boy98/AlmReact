<?php

include('conexion.php');
include('plantilla2.php'); 

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1>Nuevo Usuario</h1>
      </div>
        
      
<form class="needs-validation" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>">
                          <div class="row g-3">
                            <div class="col-sm-12">
                                <label for="Nombre" class="form-label">Nombre</label>
                              <input type="text" class="form-control" name="user" placeholder="Nombre de Usuario" value="" required>
                            </div>
                            <div class="col-sm-12">
                             <label for="Contraseña" class="form-label">Contraseña</label>
                              <input type="password" class="form-control" name="pass" placeholder="Contraseña" value="" required>
                            </div>
                            <div class="col-sm-12">
                             <label for="Confirmar Contraseña" class="form-label">Confirmar Contraseña</label>
                              <input type="password" class="form-control" name="passconf" placeholder="Confirme su Contraseña" value="" required>
                            </div>
                            <div class="text-end">
                            <?php 
                      if (isset($_POST['agregar'])) {

                        $user = $_POST['user'];
                        $pass = $_POST['pass'];
                        $passconf = $_POST['passconf'];
                                          
                                              if($pass == $passconf) {

                                                $solicitud = "INSERT INTO users (user, pass) VALUES('$user', '$pass')";
                                                $resultado = mysqli_query($conexion, $solicitud);

                                              }else{

                              echo "Error Confirmando Contraseña";
                                                  
                                              }


                      }
                      ?>
                      </div>
                            <div class="text-end">
                          <a href="gestuser.php" class="btn btn-secondary">Volver</a>
                            <input type="submit" class="btn btn-primary" name="agregar" value="Añadir">
                            </div>
                          </div>
                          
                      </form>
                     
      </div>
    </main>
  </div>
</div>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="assets/js/dashboard.js"></script>
  </body>
</html>