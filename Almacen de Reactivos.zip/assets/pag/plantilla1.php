<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.104.2">
    <title>AlmReact - Index</title>   

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../DataTables-1.13.1/css/jquery.dataTables.min.css">
    <!-- Custom styles for this template -->
    <link href="../css/dashboard.css" rel="stylesheet">
    <link href="../DataTables-1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script tipe="text/javascript" src="../jQuery-3.6.0/jquery-3.6.0.js"></script>
    <script tipe="text/javascript" src="../DataTables-1.13.1/js/jquery.dataTables.min.js"></script>
  <body>
    
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6" href="#">
    <img src="../img/Logo.png" alt="" width="20px">
    AlmReact</a>
 
</header>

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3 sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="../../index.php">
             <h5> Autenticarse </h5>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="verreact.php">
            <h5> Reactivos Disponibles </h5>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="verutiles.php">
              <h5> Útiles Disponibles </h5>
            </a>
          </li>
          
        </ul>
      </div>
    </nav> 
  </div>
</div>
</div>
</div>

    <script src="../js/bootstrap.bundle.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="../js/dashboard.js"></script>
  </body>
</html>
